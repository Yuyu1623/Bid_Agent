# 本地 GitHub 更新与敏感文件检查指南

这个文件只供本机维护项目时使用，不上传 GitHub。

## 1. 绝对不要提交的内容

以下内容只应该保留在本地：

```text
.env
.env.*
.venv/
.mineru-venv/
venv/
env/
electron_client/node_modules/
electron_client/dist/
__pycache__/
*.pyc
*.pyo
logs/
*.log
data/*.db
data/*.db-*
outputs/
output/
uploads/
temp/
tmp/
```

例外：

```text
.env.example
```

`.env.example` 可以提交，因为它只放变量名和示例值，不放真实 API Key、Token、本地路径或账号信息。

## 2. 每次提交前检查

先看当前改动：

```bash
git status --short
```

检查 `.env` 是否被 Git 跟踪：

```bash
git ls-files .env
```

如果有输出，说明 `.env` 已经被纳入 Git 索引，需要移除索引但保留本地文件：

```bash
git rm --cached .env
```

继续检查常见不应提交目录：

```bash
git ls-files .venv .mineru-venv venv env
git ls-files electron_client/node_modules electron_client/dist
git ls-files __pycache__ logs outputs output uploads temp tmp
git ls-files data
```

如果这些命令有输出，按实际路径移除索引，例如：

```bash
git rm -r --cached .venv
git rm -r --cached .mineru-venv
git rm -r --cached electron_client/node_modules
git rm -r --cached electron_client/dist
git rm -r --cached __pycache__
git rm -r --cached logs
git rm -r --cached outputs
git rm -r --cached uploads
git rm -r --cached data
```

如果提示路径不存在、没有匹配文件或没有被跟踪，可以忽略。

## 3. 大文件检查

GitHub 普通仓库不适合直接提交构建产物、安装包、数据库和依赖目录。

提交前可以查看大文件：

```bash
git status --short
git diff --stat
```

重点避免这些内容：

```text
*.exe
*.msi
*.zip
*.7z
*.db
electron_client/dist/
electron_client/node_modules/
```

如果误加入大文件：

```bash
git rm --cached path/to/large-file
```

如果是目录：

```bash
git rm -r --cached path/to/directory
```

## 4. 推荐提交流程

确认工作区：

```bash
git status --short
```

添加文件：

```bash
git add .
```

再次检查：

```bash
git status --short
git ls-files .env
```

确认没有敏感文件后提交：

```bash
git commit -m "Update bid agent features"
```

推送到 GitHub：

```bash
git push origin master
```

如果远端默认分支是 `main`，使用：

```bash
git push origin main
```

## 5. 如果 GitHub 拒绝大文件

如果出现类似：

```text
GH001: Large files detected
```

通常是构建产物、exe、node_modules 或数据库被提交了。

处理方式：

```bash
git rm --cached path/to/large-file
git commit -m "Remove large generated file"
git push origin master
```

如果大文件已经进入历史提交，需要重写历史或重新整理分支。操作前先备份项目，不要直接 `git reset --hard`。

## 6. 如果密钥已经推送过

如果 `.env`、API Key、MinerU Token、LLM Key 等已经推送到 GitHub：

1. 立即到对应平台后台禁用或重置密钥。
2. 本地 `.env` 换成新密钥。
3. 确认 `.env` 在 `.gitignore` 中。
4. 从 Git 索引移除 `.env`：

```bash
git rm --cached .env
git commit -m "Remove local env file from git tracking"
git push origin master
```

注意：从最新提交删除 `.env` 不等于清除历史记录。只要密钥曾经公开过，就应该更换。

## 7. 本项目当前建议提交内容

通常可以提交：

```text
*.py
README.md
DATABASE_SCHEMA_DESIGN.md
MINERU_LOCAL_DEPLOY.md
.env.example
.gitignore
requirements.txt
docs/招投标智能体数据库表结构.xlsx
scripts/
electron_client/main.js
electron_client/preload.js
electron_client/renderer.html
electron_client/renderer.js
electron_client/styles.css
electron_client/package.json
electron_client/package-lock.json
```

通常不提交：

```text
LOCAL_GITHUB_GUIDE.md
.env
data/
logs/
outputs/
uploads/
electron_client/dist/
electron_client/node_modules/
```
